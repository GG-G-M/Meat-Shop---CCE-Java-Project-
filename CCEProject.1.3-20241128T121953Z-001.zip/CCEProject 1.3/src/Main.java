import java.io.*;
import javax.swing.*;
import java.awt.*;
public class Main {
    //__Main RUN--
    public static void main(String[]args) throws IOException{
        
        AdminPage.init();
        MainPage.init();
         
 
    }
}